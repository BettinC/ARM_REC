Car converted from RC Revenge Pro by MightyCucumber and URV using Ninja Ripper, 3DS Max, Blender + Jig's Plugin and Photoshop.

Remmapped body.prm, custom engine sound and alternate skin provided by FZG. 