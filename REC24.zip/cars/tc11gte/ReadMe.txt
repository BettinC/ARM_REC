Splat GTE by burner94 and Ionico

The main skin, used for the carbox, has been made by Marco repainter, and the racing number on it is the number of Drakan, winner of the Splat Team Championship. All the other skins were made by the participants of the Splat Team Championship and the Re-Volt IO Splat GTE Tournament.
