Made by rodik for Game Show Community Edition 2024.
Using instances by Kiwi, Zorbah and Chris.